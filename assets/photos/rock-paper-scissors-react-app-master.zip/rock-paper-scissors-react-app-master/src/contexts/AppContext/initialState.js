export const initialState = {
  playerChoice: false,
  machineChoice: false,
  score: 0,
  result: '',
};
